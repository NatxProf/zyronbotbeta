'use strict';

const { PermissionsBitField } = require('discord.js');
const { upsertGuild } = require('../../database/guildSchema');
const { buildSuccessEmbed, buildErrorEmbed } = require('../../utils/embedBuilder');

const MAX_PREFIX_LENGTH = 5;

module.exports = {
  name:        'prefix',
  description: 'Change the command prefix for this server.',
  usage:       'zt!prefix <new_prefix>',
  permissions: [PermissionsBitField.Flags.Administrator],

  async execute(message, args, client) {
    const newPrefix = args[0];

    if (!newPrefix) {
      return message.reply({
        embeds: [buildErrorEmbed('Missing Prefix', `Provide the new prefix. Example: \`${client.prefix}prefix !\``)]
      });
    }

    if (newPrefix.length > MAX_PREFIX_LENGTH) {
      return message.reply({
        embeds: [buildErrorEmbed('Prefix Too Long', `Prefixes must be ${MAX_PREFIX_LENGTH} characters or fewer.`)]
      });
    }

    upsertGuild(message.guild.id, { prefix: newPrefix });
    client.prefix = newPrefix;

    await message.reply({
      embeds: [buildSuccessEmbed(
        'Prefix Updated',
        `The command prefix for this server has been changed to \`${newPrefix}\`.`
      )]
    });
  }
};
