'use strict';

const { PermissionsBitField } = require('discord.js');
const { setManualStatus, resumeRotator } = require('../../status/rotator');
const { buildSuccessEmbed, buildErrorEmbed } = require('../../utils/embedBuilder');

const VALID_TYPES = ['PLAYING', 'WATCHING', 'LISTENING', 'COMPETING'];

module.exports = {
  name:        'status',
  description: 'Manually set the bot status or resume automatic rotation.',
  usage:       'zt!status set <TYPE> <text> | zt!status reset',
  permissions: [PermissionsBitField.Flags.Administrator],

  async execute(message, args, client) {
    const sub = args[0]?.toLowerCase();

    if (sub === 'reset') {
      resumeRotator(client);
      return message.reply({
        embeds: [buildSuccessEmbed('Status Reset', 'Automatic status rotation has been resumed.')]
      });
    }

    if (sub === 'set') {
      const type = args[1]?.toUpperCase();
      const text = args.slice(2).join(' ');

      if (!type || !VALID_TYPES.includes(type)) {
        return message.reply({
          embeds: [buildErrorEmbed(
            'Invalid Type',
            `Valid activity types: \`${VALID_TYPES.join('`, `')}\``
          )]
        });
      }

      if (!text) {
        return message.reply({
          embeds: [buildErrorEmbed('Missing Text', 'Provide the status text. Example: `zt!status set PLAYING something`')]
        });
      }

      setManualStatus(client, { type, text });

      return message.reply({
        embeds: [buildSuccessEmbed('Status Updated', `Status set to **${type}** "${text}".`)]
      });
    }

    await message.reply({
      embeds: [buildErrorEmbed(
        'Invalid Subcommand',
        'Usage:\n`zt!status set <TYPE> <text>`\n`zt!status reset`'
      )]
    });
  }
};
