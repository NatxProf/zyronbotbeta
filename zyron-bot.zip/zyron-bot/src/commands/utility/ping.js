'use strict';

const { buildInfoEmbed } = require('../../utils/embedBuilder');

module.exports = {
  name:        'ping',
  description: 'Check Zyron\'s response latency and WebSocket heartbeat.',
  usage:       'zt!ping',
  cooldown:    5,

  async execute(message, args, client) {
    const sent = await message.reply({ content: 'Measuring latency...' });

    const roundTrip = sent.createdTimestamp - message.createdTimestamp;
    const wsLatency = Math.round(client.ws.ping);

    await sent.edit({
      content: '',
      embeds: [buildInfoEmbed(
        '🏓 Pong!',
        `**Round-trip Latency:** ${roundTrip}ms\n**WebSocket Heartbeat:** ${wsLatency}ms`
      )]
    });
  }
};
