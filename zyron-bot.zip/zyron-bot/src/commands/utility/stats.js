'use strict';

const { EmbedBuilder } = require('discord.js');
const config = require('../../../config.json');

function formatUptime(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  const d = Math.floor(h / 24);
  return `${d}d ${h % 24}h ${m % 60}m ${s % 60}s`;
}

module.exports = {
  name:        'stats',
  description: 'Display current Zyron statistics.',
  usage:       'zt!stats',
  cooldown:    10,

  async execute(message, args, client) {
    const memMB = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);

    const embed = new EmbedBuilder()
      .setColor(config.colors.primary)
      .setTitle('📊 Zyron Statistics')
      .addFields(
        { name: 'Guilds',        value: `${client.guilds.cache.size}`,     inline: true },
        { name: 'Cached Users',  value: `${client.users.cache.size}`,      inline: true },
        { name: 'Uptime',        value: formatUptime(client.uptime),       inline: true },
        { name: 'Latency',       value: `${Math.round(client.ws.ping)}ms`, inline: true },
        { name: 'Memory',        value: `${memMB} MB`,                     inline: true },
        { name: 'Commands',      value: `${client.commands.size}`,         inline: true }
      )
      .setFooter({ text: config.embedFooter })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  }
};
