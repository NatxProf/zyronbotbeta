'use strict';

const { EmbedBuilder } = require('discord.js');
const config = require('../../../config.json');

const CATEGORIES = {
  ticket:  { label: '🎫 Ticket Management',   prefix: 'zt!ticket' },
  admin:   { label: '🛡️ Administration',       prefix: 'zt!'        },
  utility: { label: '🔧 Utility',              prefix: 'zt!'        },
  config:  { label: '⚙️ Configuration',        prefix: 'zt!'        }
};

const COMMAND_LIST = {
  ticket:  [
    '`zt!ticket setup [category_id]` — Initialize the ticket system',
    '`zt!ticket enable` — Activate ticket functionality',
    '`zt!ticket disable` — Deactivate ticket functionality',
    '`zt!ticket panel` — Deploy the ticket creation panel',
    '`zt!ticket close` — Close the current ticket channel',
    '`zt!ticket logs <#channel>` — Set the activity log channel'
  ],
  admin: [
    '`zt!say <message>` — Send a message as Zyron',
    '`zt!announce <message>` — Post a formatted announcement',
    '`zt!embed <title> | <desc>` — Send a structured embed',
    '`zt!purge <amount>` — Bulk delete messages (max 100)'
  ],
  utility: [
    '`zt!help` — Display this help menu',
    '`zt!ping` — Check bot response latency',
    '`zt!stats` — View bot statistics'
  ],
  config: [
    '`zt!prefix <new_prefix>` — Change the guild command prefix',
    '`zt!status set <TYPE> <text>` — Set a custom bot status',
    '`zt!status reset` — Resume automatic status rotation'
  ]
};

module.exports = {
  name:        'help',
  description: 'Display all available commands organized by category.',
  usage:       'zt!help',

  async execute(message, args, client) {
    const embed = new EmbedBuilder()
      .setColor(config.colors.primary)
      .setTitle('Zyron — Command Reference')
      .setDescription(
        'Below is a complete list of available commands. ' +
        'Arguments in `<>` are required; `[]` denotes optional.\n\u200b'
      )
      .setFooter({ text: config.embedFooter })
      .setTimestamp();

    for (const [key, meta] of Object.entries(CATEGORIES)) {
      embed.addFields({
        name:   meta.label,
        value:  COMMAND_LIST[key].join('\n'),
        inline: false
      });
    }

    await message.reply({ embeds: [embed] });
  }
};
