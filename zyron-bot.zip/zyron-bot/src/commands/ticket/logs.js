'use strict';

const { PermissionsBitField, ChannelType } = require('discord.js');
const { upsertGuild } = require('../../database/guildSchema');
const { buildSuccessEmbed, buildErrorEmbed } = require('../../utils/embedBuilder');

module.exports = {
  name:        'ticket',
  subcommand:  'logs',
  description: 'Set the channel where ticket activity is logged.',
  usage:       'zt!ticket logs <#channel>',
  permissions: [PermissionsBitField.Flags.Administrator],

  async execute(message, args, client) {
    const channel = message.mentions.channels.first();

    if (!channel) {
      return message.reply({
        embeds: [buildErrorEmbed('Missing Channel', 'Please mention a valid text channel. Example: `zt!ticket logs #ticket-logs`')]
      });
    }

    if (channel.type !== ChannelType.GuildText) {
      return message.reply({
        embeds: [buildErrorEmbed('Invalid Channel', 'The log channel must be a standard text channel.')]
      });
    }

    upsertGuild(message.guild.id, { ticket_log_channel_id: channel.id });

    await message.reply({
      embeds: [buildSuccessEmbed(
        'Log Channel Set',
        `Ticket activity will now be recorded in ${channel}.`
      )]
    });
  }
};
