'use strict';

const { PermissionsBitField, AttachmentBuilder } = require('discord.js');
const { getTicketByChannel, closeTicketRecord } = require('../../tickets/ticketDB');
const { getGuild } = require('../../database/guildSchema');
const { sendToLogChannel } = require('../../tickets/ticketHandler');
const { generateTranscript } = require('../../tickets/transcript');
const { buildErrorEmbed, buildSuccessEmbed, buildEmbed } = require('../../utils/embedBuilder');
const logger = require('../../core/logger');
const config = require('../../../config.json');

async function closeTicketChannel(source, client, isInteraction = false) {
  const channel = source.channel;
  const closer  = isInteraction ? source.user : source.author;
  const guild   = source.guild;

  const ticket = getTicketByChannel(channel.id);
  if (!ticket || ticket.status !== 'open') {
    const payload = {
      embeds:    [buildErrorEmbed('Not a Ticket', 'This command can only be used inside an open ticket channel.')],
      ephemeral: isInteraction
    };
    return isInteraction
      ? source.reply(payload)
      : source.reply(payload);
  }

  const guildConfig = getGuild(guild.id);

  try {
    if (isInteraction) await source.deferReply({ ephemeral: true });

    const transcriptPath = await generateTranscript(channel, ticket);

    closeTicketRecord(channel.id, closer.id);

    const logEmbed = buildEmbed({
      color:       config.colors.error,
      title:       '🔒 Ticket Closed',
      description:
        `**Ticket #:** ${ticket.ticket_number}\n` +
        `**User:** <@${ticket.user_id}>\n` +
        `**Closed By:** ${closer.tag}\n` +
        `**Channel:** ${channel.name}`
    });

    if (guildConfig?.ticket_log_channel_id) {
      const logChannel = guild.channels.cache.get(guildConfig.ticket_log_channel_id);
      if (logChannel) {
        const messagePayload = { embeds: [logEmbed] };
        if (transcriptPath) {
          messagePayload.files = [new AttachmentBuilder(transcriptPath)];
        }
        await logChannel.send(messagePayload).catch(() => {});
      }
    }

    await channel.send({
      embeds: [buildSuccessEmbed('Ticket Closed', 'This ticket has been closed. The channel will be deleted shortly.')]
    });

    if (isInteraction) {
      await source.editReply({ embeds: [buildSuccessEmbed('Closed', 'The ticket has been closed successfully.')] });
    }

    setTimeout(() => channel.delete().catch(() => {}), 5000);

  } catch (err) {
    logger.error(`Failed to close ticket [${channel.id}]: ${err.message}`);
    const errPayload = {
      embeds: [buildErrorEmbed('Close Failed', 'An error occurred while closing this ticket.')]
    };
    isInteraction
      ? source.editReply(errPayload).catch(() => {})
      : source.reply(errPayload).catch(() => {});
  }
}

module.exports = {
  name:        'ticket',
  subcommand:  'close',
  description: 'Close the current support ticket.',
  usage:       'zt!ticket close',
  permissions: [PermissionsBitField.Flags.ManageChannels],

  async execute(message, args, client) {
    await closeTicketChannel(message, client, false);
  },

  closeTicketChannel
};
