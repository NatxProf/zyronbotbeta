'use strict';

const { PermissionsBitField } = require('discord.js');
const { getGuild } = require('../../database/guildSchema');
const { buildTicketPanel } = require('../../tickets/ticketPanel');
const { buildErrorEmbed }  = require('../../utils/embedBuilder');

module.exports = {
  name:        'ticket',
  subcommand:  'panel',
  description: 'Send the ticket creation panel to this channel.',
  usage:       'zt!ticket panel',
  permissions: [PermissionsBitField.Flags.Administrator],

  async execute(message, args, client) {
    const config = getGuild(message.guild.id);

    if (!config?.ticket_enabled) {
      return message.reply({
        embeds: [buildErrorEmbed('Tickets Disabled', 'Enable the ticket system first with `zt!ticket enable`.')]
      });
    }

    await message.channel.send(buildTicketPanel());
    await message.delete().catch(() => {});
  }
};
