'use strict';

const { PermissionsBitField } = require('discord.js');
const { upsertGuild, getGuild } = require('../../database/guildSchema');
const { buildSuccessEmbed, buildWarningEmbed } = require('../../utils/embedBuilder');

module.exports = {
  name:        'ticket',
  subcommand:  'disable',
  description: 'Deactivate the ticket system.',
  usage:       'zt!ticket disable',
  permissions: [PermissionsBitField.Flags.Administrator],

  async execute(message, args, client) {
    const config = getGuild(message.guild.id);

    if (!config?.ticket_enabled) {
      return message.reply({
        embeds: [buildWarningEmbed('Already Disabled', 'The ticket system is not currently active.')]
      });
    }

    upsertGuild(message.guild.id, { ticket_enabled: 0 });

    await message.reply({
      embeds: [buildSuccessEmbed(
        'Ticket System Disabled',
        'New tickets can no longer be created. Existing open tickets are unaffected.'
      )]
    });
  }
};
