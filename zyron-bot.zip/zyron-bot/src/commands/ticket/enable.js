'use strict';

const { PermissionsBitField } = require('discord.js');
const { upsertGuild, getGuild } = require('../../database/guildSchema');
const { buildSuccessEmbed, buildWarningEmbed } = require('../../utils/embedBuilder');

module.exports = {
  name:        'ticket',
  subcommand:  'enable',
  description: 'Activate the ticket system.',
  usage:       'zt!ticket enable',
  permissions: [PermissionsBitField.Flags.Administrator],

  async execute(message, args, client) {
    const config = getGuild(message.guild.id);

    if (config?.ticket_enabled) {
      return message.reply({
        embeds: [buildWarningEmbed('Already Enabled', 'The ticket system is already active on this server.')]
      });
    }

    upsertGuild(message.guild.id, { ticket_enabled: 1 });

    await message.reply({
      embeds: [buildSuccessEmbed(
        'Ticket System Enabled',
        'Users can now create support tickets. Use `zt!ticket panel` to deploy the panel.'
      )]
    });
  }
};
