'use strict';

const { PermissionsBitField } = require('discord.js');
const { upsertGuild } = require('../../database/guildSchema');
const { buildSuccessEmbed, buildErrorEmbed } = require('../../utils/embedBuilder');

module.exports = {
  name:        'ticket',
  subcommand:  'setup',
  description: 'Initialize the ticket system for this server.',
  usage:       'zt!ticket setup [category_id]',
  permissions: [PermissionsBitField.Flags.Administrator],
  category:    'ticket',

  async execute(message, args, client) {
    const categoryId = args[0] ?? null;

    upsertGuild(message.guild.id, {
      ticket_category_id: categoryId
    });

    const nextSteps =
      '**Next Steps**\n' +
      '`zt!ticket logs #channel` — Set the log channel\n' +
      (categoryId ? '' : '`zt!ticket category <id>` — Set a ticket category\n') +
      '`zt!ticket enable` — Activate the ticket system\n' +
      '`zt!ticket panel` — Deploy the ticket creation panel';

    await message.reply({
      embeds: [buildSuccessEmbed(
        'Ticket System Initialized',
        `The ticket system has been configured for **${message.guild.name}**.\n\n${nextSteps}`
      )]
    });
  }
};
