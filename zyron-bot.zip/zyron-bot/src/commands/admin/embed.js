'use strict';

const { PermissionsBitField } = require('discord.js');
const { buildEmbed, buildErrorEmbed } = require('../../utils/embedBuilder');
const { isValidHexColor } = require('../../utils/validators');
const config = require('../../../config.json');

module.exports = {
  name:        'embed',
  description: 'Send a structured embed. Format: zt!embed Title | Description | #HexColor (color optional)',
  usage:       'zt!embed <title> | <description> [| #color]',
  permissions: [PermissionsBitField.Flags.ManageMessages],
  cooldown:    5,

  async execute(message, args, client) {
    const input = args.join(' ');
    const parts = input.split('|').map(p => p.trim());

    if (parts.length < 2) {
      return message.reply({
        embeds: [buildErrorEmbed(
          'Invalid Format',
          'Use the format: `zt!embed Title | Description | #HexColor`\nColor is optional.'
        )]
      });
    }

    const [title, description, colorInput] = parts;
    const color = colorInput && isValidHexColor(colorInput)
      ? colorInput
      : config.colors.primary;

    const embed = buildEmbed({ color, title, description });
    await message.channel.send({ embeds: [embed] });
    await message.delete().catch(() => {});
  }
};
