'use strict';

const { PermissionsBitField } = require('discord.js');
const { buildSuccessEmbed, buildErrorEmbed } = require('../../utils/embedBuilder');
const { isPositiveInteger } = require('../../utils/validators');

module.exports = {
  name:        'purge',
  description: 'Bulk delete messages from the current channel (max 100).',
  usage:       'zt!purge <amount>',
  permissions: [PermissionsBitField.Flags.ManageMessages],
  cooldown:    5,

  async execute(message, args, client) {
    const amount = parseInt(args[0], 10);

    if (!args[0] || !isPositiveInteger(args[0]) || amount > 100) {
      return message.reply({
        embeds: [buildErrorEmbed('Invalid Amount', 'Provide a number between 1 and 100. Example: `zt!purge 25`')]
      });
    }

    await message.delete().catch(() => {});

    const deleted = await message.channel.bulkDelete(amount, true).catch(() => null);

    if (!deleted) {
      return message.channel.send({
        embeds: [buildErrorEmbed('Purge Failed', 'Unable to delete messages. Messages older than 14 days cannot be bulk deleted.')]
      });
    }

    const confirmation = await message.channel.send({
      embeds: [buildSuccessEmbed('Messages Purged', `Successfully deleted **${deleted.size}** message(s).`)]
    });

    setTimeout(() => confirmation.delete().catch(() => {}), 4000);
  }
};
