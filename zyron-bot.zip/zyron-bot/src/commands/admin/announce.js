'use strict';

const { PermissionsBitField } = require('discord.js');
const { buildEmbed, buildErrorEmbed } = require('../../utils/embedBuilder');
const config = require('../../../config.json');

module.exports = {
  name:        'announce',
  description: 'Send a formatted announcement embed.',
  usage:       'zt!announce <message>',
  permissions: [PermissionsBitField.Flags.ManageMessages],
  cooldown:    10,

  async execute(message, args, client) {
    if (!args.length) {
      return message.reply({
        embeds: [buildErrorEmbed('Missing Content', 'Provide the announcement text. Example: `zt!announce Server maintenance at 8 PM.`')]
      });
    }

    const content = args.join(' ');

    const embed = buildEmbed({
      color:       config.colors.info,
      title:       '📢 Server Announcement',
      description: content,
      fields:      [{ name: 'Posted by', value: message.author.tag, inline: true }]
    });

    await message.channel.send({ embeds: [embed] });
    await message.delete().catch(() => {});
  }
};
