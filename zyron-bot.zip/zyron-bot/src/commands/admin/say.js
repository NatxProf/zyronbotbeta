'use strict';

const { PermissionsBitField } = require('discord.js');
const { buildErrorEmbed } = require('../../utils/embedBuilder');
const { sanitize } = require('../../utils/validators');

module.exports = {
  name:        'say',
  description: 'Send a plain-text message as Zyron.',
  usage:       'zt!say <message>',
  permissions: [PermissionsBitField.Flags.ManageMessages],
  cooldown:    5,

  async execute(message, args, client) {
    if (!args.length) {
      return message.reply({
        embeds: [buildErrorEmbed('Missing Message', 'Provide the message content. Example: `zt!say Hello, server!`')]
      });
    }

    const content = sanitize(args.join(' '));
    await message.channel.send(content);
    await message.delete().catch(() => {});
  }
};
