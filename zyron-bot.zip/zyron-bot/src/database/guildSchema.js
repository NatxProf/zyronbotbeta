'use strict';

function applyGuildSchema(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS guilds (
      guild_id              TEXT PRIMARY KEY,
      prefix                TEXT    NOT NULL DEFAULT 'zt!',
      ticket_enabled        INTEGER NOT NULL DEFAULT 0,
      ticket_category_id    TEXT,
      ticket_log_channel_id TEXT,
      ticket_counter        INTEGER NOT NULL DEFAULT 0,
      created_at            TEXT    NOT NULL DEFAULT (datetime('now'))
    );
  `);
}

function getGuild(guildId) {
  const { getDatabase } = require('./sqlite');
  return getDatabase()
    .prepare('SELECT * FROM guilds WHERE guild_id = ?')
    .get(guildId);
}

function upsertGuild(guildId, data = {}) {
  const { getDatabase } = require('./sqlite');
  const db = getDatabase();
  const existing = getGuild(guildId);

  if (!existing) {
    db.prepare(`
      INSERT INTO guilds (guild_id, prefix, ticket_enabled, ticket_category_id, ticket_log_channel_id)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      guildId,
      data.prefix                || 'zt!',
      data.ticket_enabled        || 0,
      data.ticket_category_id    || null,
      data.ticket_log_channel_id || null
    );
  } else {
    const fields = Object.keys(data).map(k => `${k} = ?`).join(', ');
    if (!fields) return;
    getDatabase()
      .prepare(`UPDATE guilds SET ${fields} WHERE guild_id = ?`)
      .run(...Object.values(data), guildId);
  }
}

function incrementTicketCounter(guildId) {
  const { getDatabase } = require('./sqlite');
  const db = getDatabase();
  db.prepare(`
    UPDATE guilds SET ticket_counter = ticket_counter + 1 WHERE guild_id = ?
  `).run(guildId);
  return db.prepare('SELECT ticket_counter FROM guilds WHERE guild_id = ?')
    .get(guildId)?.ticket_counter ?? 1;
}

module.exports = { applyGuildSchema, getGuild, upsertGuild, incrementTicketCounter };
