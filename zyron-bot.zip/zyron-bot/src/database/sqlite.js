'use strict';

const Database = require('better-sqlite3');
const path     = require('path');
const fs       = require('fs');
const logger   = require('../core/logger');
const { applyGuildSchema }  = require('./guildSchema');
const { applyTicketSchema } = require('./ticketSchema');

let db = null;

function getDatabase() {
  if (db) return db;

  const dataDir = path.join(__dirname, '../../data');
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

  db = new Database(path.join(dataDir, 'zyron.db'));
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  applyGuildSchema(db);
  applyTicketSchema(db);

  logger.info('SQLite database initialized successfully.');
  return db;
}

module.exports = { getDatabase };
