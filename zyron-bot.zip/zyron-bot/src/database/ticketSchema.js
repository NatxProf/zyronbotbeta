'use strict';

function applyTicketSchema(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS tickets (
      ticket_id     TEXT PRIMARY KEY,
      guild_id      TEXT    NOT NULL,
      channel_id    TEXT    NOT NULL UNIQUE,
      user_id       TEXT    NOT NULL,
      ticket_number INTEGER NOT NULL,
      status        TEXT    NOT NULL DEFAULT 'open',
      description   TEXT,
      created_at    TEXT    NOT NULL DEFAULT (datetime('now')),
      closed_at     TEXT,
      closed_by     TEXT,
      FOREIGN KEY (guild_id) REFERENCES guilds (guild_id)
    );
  `);
}

function createTicketRecord(data) {
  const { getDatabase } = require('./sqlite');
  getDatabase().prepare(`
    INSERT INTO tickets (ticket_id, guild_id, channel_id, user_id, ticket_number, description)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(
    data.ticket_id,
    data.guild_id,
    data.channel_id,
    data.user_id,
    data.ticket_number,
    data.description ?? null
  );
}

function getTicketByChannel(channelId) {
  const { getDatabase } = require('./sqlite');
  return getDatabase()
    .prepare('SELECT * FROM tickets WHERE channel_id = ?')
    .get(channelId);
}

function getOpenTicketByUser(guildId, userId) {
  const { getDatabase } = require('./sqlite');
  return getDatabase()
    .prepare(`SELECT * FROM tickets WHERE guild_id = ? AND user_id = ? AND status = 'open'`)
    .get(guildId, userId);
}

function closeTicketRecord(channelId, closedById) {
  const { getDatabase } = require('./sqlite');
  getDatabase().prepare(`
    UPDATE tickets
    SET status = 'closed', closed_at = datetime('now'), closed_by = ?
    WHERE channel_id = ?
  `).run(closedById, channelId);
}

module.exports = {
  applyTicketSchema,
  createTicketRecord,
  getTicketByChannel,
  getOpenTicketByUser,
  closeTicketRecord
};
