'use strict';

const logger        = require('../core/logger');
const { getDatabase }  = require('../database/sqlite');
const { startRotator } = require('../status/rotator');

module.exports = {
  name:  'ready',
  once:  true,
  async execute(client) {
    logger.info(`Zyron is online — logged in as ${client.user.tag}`);
    logger.info(`Serving ${client.guilds.cache.size} guild(s) | ${client.users.cache.size} cached user(s)`);

    getDatabase();
    startRotator(client);
  }
};
