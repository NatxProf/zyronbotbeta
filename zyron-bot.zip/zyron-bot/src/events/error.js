'use strict';

const logger = require('../core/logger');

module.exports = {
  name: 'error',
  async execute(error, client) {
    logger.error(`Discord client error: ${error.message}`);
  }
};
