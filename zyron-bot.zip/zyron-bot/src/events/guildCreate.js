'use strict';

const { upsertGuild } = require('../database/guildSchema');
const logger = require('../core/logger');

module.exports = {
  name: 'guildCreate',
  async execute(guild, client) {
    upsertGuild(guild.id, {});
    logger.info(`Joined guild: "${guild.name}" (${guild.id}) — ${guild.memberCount} members`);
  }
};
