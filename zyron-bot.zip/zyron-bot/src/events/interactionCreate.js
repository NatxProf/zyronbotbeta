'use strict';

const { handleTicketCreate, processTicketSubmission } = require('../tickets/createTicket');
const { buildErrorEmbed } = require('../utils/embedBuilder');
const logger = require('../core/logger');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    try {
      if (interaction.isButton()) {
        if (interaction.customId === 'ticket_create') {
          return await handleTicketCreate(interaction);
        }
        if (interaction.customId === 'ticket_close') {
          const { closeTicketChannel } = require('../commands/ticket/close');
          return await closeTicketChannel(interaction, client, true);
        }
      }

      if (interaction.isModalSubmit()) {
        if (interaction.customId === 'ticket_submit_modal') {
          return await processTicketSubmission(interaction, client);
        }
      }
    } catch (err) {
      logger.error(`Interaction error [${interaction.customId ?? 'unknown'}]: ${err.message}`);
      const payload = {
        embeds:    [buildErrorEmbed('Interaction Error', 'Something went wrong. Please try again.')],
        ephemeral: true
      };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(payload).catch(() => {});
      } else {
        await interaction.reply(payload).catch(() => {});
      }
    }
  }
};
