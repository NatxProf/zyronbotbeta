'use strict';

const { handleCommand } = require('../core/handler');

module.exports = {
  name: 'messageCreate',
  async execute(message, client) {
    if (message.author.bot || !message.guild) return;
    await handleCommand(message, client);
  }
};
