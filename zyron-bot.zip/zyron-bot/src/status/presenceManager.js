'use strict';

const { ActivityType } = require('discord.js');

const ACTIVITY_MAP = {
  PLAYING:   ActivityType.Playing,
  WATCHING:  ActivityType.Watching,
  LISTENING: ActivityType.Listening,
  COMPETING: ActivityType.Competing
};

function setPresence(client, { type, text }) {
  client.user?.setPresence({
    activities: [{
      name: text,
      type: ACTIVITY_MAP[type] ?? ActivityType.Watching
    }],
    status: 'online'
  });
}

module.exports = { setPresence };
