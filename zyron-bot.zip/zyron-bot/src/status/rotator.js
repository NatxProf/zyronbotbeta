'use strict';

const config  = require('../../config.json');
const logger  = require('../core/logger');
const { setPresence } = require('./presenceManager');

let intervalHandle = null;
let currentIndex   = 0;

function startRotator(client) {
  const statuses = config.statusMessages;
  if (!statuses?.length) return;

  setPresence(client, statuses[0]);

  intervalHandle = setInterval(() => {
    currentIndex = (currentIndex + 1) % statuses.length;
    setPresence(client, statuses[currentIndex]);
  }, config.statusRotateInterval ?? 30_000);

  logger.info(`Status rotator started — cycling ${statuses.length} status(es).`);
}

function stopRotator() {
  if (intervalHandle) {
    clearInterval(intervalHandle);
    intervalHandle = null;
  }
}

function setManualStatus(client, statusObj) {
  stopRotator();
  setPresence(client, statusObj);
}

function resumeRotator(client) {
  stopRotator();
  startRotator(client);
}

module.exports = { startRotator, stopRotator, setManualStatus, resumeRotator };
