'use strict';

const { PermissionsBitField } = require('discord.js');

function hasPermission(member, permissions) {
  if (!member || !permissions) return true;
  if (member.guild.ownerId === member.id) return true;
  if (member.permissions.has(PermissionsBitField.Flags.Administrator)) return true;
  return member.permissions.has(permissions);
}

function isAdmin(member) {
  return (
    member.guild.ownerId === member.id ||
    member.permissions.has(PermissionsBitField.Flags.Administrator)
  );
}

function hasAnyRole(member, roleIds = []) {
  return member.roles.cache.some(role => roleIds.includes(role.id));
}

module.exports = { hasPermission, isAdmin, hasAnyRole };
