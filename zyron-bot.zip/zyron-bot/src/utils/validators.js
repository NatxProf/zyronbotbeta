'use strict';

function isValidUrl(str) {
  try { new URL(str); return true; }
  catch { return false; }
}

function isValidHexColor(str) {
  return /^#[0-9A-Fa-f]{6}$/.test(str);
}

function truncate(str, max = 1000) {
  return str.length <= max ? str : str.slice(0, max - 3) + '...';
}

function sanitize(str) {
  return str.replace(/[<>]/g, '').trim();
}

function isPositiveInteger(str) {
  const n = parseInt(str, 10);
  return !isNaN(n) && n > 0;
}

module.exports = { isValidUrl, isValidHexColor, truncate, sanitize, isPositiveInteger };
