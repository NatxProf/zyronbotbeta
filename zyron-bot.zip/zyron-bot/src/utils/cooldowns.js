'use strict';

const store = new Map();

function getCooldown(key) {
  if (!store.has(key)) return 0;
  const expiry    = store.get(key);
  const remaining = expiry - Date.now();
  if (remaining <= 0) { store.delete(key); return 0; }
  return remaining;
}

function setCooldown(key, durationMs) {
  store.set(key, Date.now() + durationMs);
}

function clearCooldown(key) {
  store.delete(key);
}

module.exports = { getCooldown, setCooldown, clearCooldown };
