'use strict';

const { EmbedBuilder } = require('discord.js');
const config = require('../../config.json');

function buildEmbed({ color, title, description, fields, footer } = {}) {
  const embed = new EmbedBuilder()
    .setColor(color || config.colors.primary)
    .setFooter({ text: footer || config.embedFooter })
    .setTimestamp();

  if (title)       embed.setTitle(title);
  if (description) embed.setDescription(description);
  if (fields)      embed.addFields(fields);

  return embed;
}

function buildSuccessEmbed(title, description) {
  return buildEmbed({ color: config.colors.success, title, description });
}

function buildErrorEmbed(title, description) {
  return buildEmbed({ color: config.colors.error, title, description });
}

function buildInfoEmbed(title, description) {
  return buildEmbed({ color: config.colors.primary, title, description });
}

function buildWarningEmbed(title, description) {
  return buildEmbed({ color: config.colors.warning, title, description });
}

module.exports = {
  buildEmbed,
  buildSuccessEmbed,
  buildErrorEmbed,
  buildInfoEmbed,
  buildWarningEmbed
};
