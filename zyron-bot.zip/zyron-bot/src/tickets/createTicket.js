'use strict';

const {
  ChannelType,
  PermissionsBitField,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  EmbedBuilder
} = require('discord.js');

const { getGuild }            = require('../database/guildSchema');
const { openTicket, getOpenTicketByUser } = require('./ticketDB');
const { sendTicketWelcome, sendToLogChannel } = require('./ticketHandler');
const { buildErrorEmbed, buildSuccessEmbed, buildEmbed } = require('../utils/embedBuilder');
const logger = require('../core/logger');
const config = require('../../config.json');

async function handleTicketCreate(interaction) {
  const guildConfig = getGuild(interaction.guild.id);

  if (!guildConfig?.ticket_enabled) {
    return interaction.reply({
      embeds:    [buildErrorEmbed('Tickets Disabled', 'The ticket system is not currently active on this server.')],
      ephemeral: true
    });
  }

  const existing = getOpenTicketByUser(interaction.guild.id, interaction.user.id);
  if (existing) {
    return interaction.reply({
      embeds:    [buildErrorEmbed('Ticket Already Open', `You already have an open ticket: <#${existing.channel_id}>`)],
      ephemeral: true
    });
  }

  const modal = new ModalBuilder()
    .setCustomId('ticket_submit_modal')
    .setTitle('Open a Support Ticket');

  const input = new TextInputBuilder()
    .setCustomId('ticket_description')
    .setLabel('Describe your issue')
    .setStyle(TextInputStyle.Paragraph)
    .setPlaceholder('Please provide a clear and detailed description of your issue...')
    .setMinLength(config.ticket.descriptionMinLength)
    .setMaxLength(config.ticket.descriptionMaxLength)
    .setRequired(true);

  modal.addComponents(new ActionRowBuilder().addComponents(input));
  await interaction.showModal(modal);
}

async function processTicketSubmission(interaction, client) {
  const { guild, user } = interaction;
  const description     = interaction.fields.getTextInputValue('ticket_description');

  await interaction.deferReply({ ephemeral: true });

  const guildConfig = getGuild(guild.id);
  if (!guildConfig) {
    return interaction.editReply({
      embeds: [buildErrorEmbed('Configuration Error', 'Server configuration not found. Please contact an administrator.')]
    });
  }

  try {
    const channel = await guild.channels.create({
      name:   `ticket-${user.username.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      type:   ChannelType.GuildText,
      parent: guildConfig.ticket_category_id ?? null,
      permissionOverwrites: [
        {
          id:   guild.id,
          deny: [PermissionsBitField.Flags.ViewChannel]
        },
        {
          id:    user.id,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
            PermissionsBitField.Flags.ReadMessageHistory
          ]
        },
        {
          id:    client.user.id,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
            PermissionsBitField.Flags.ManageChannels,
            PermissionsBitField.Flags.ReadMessageHistory
          ]
        }
      ]
    });

    const { ticketNumber } = await openTicket({
      guildId:    guild.id,
      channelId:  channel.id,
      userId:     user.id,
      description
    });

    await sendTicketWelcome(channel, user, ticketNumber, description);

    const logEmbed = buildEmbed({
      color:       config.colors.success,
      title:       '🎫 Ticket Opened',
      description:
        `**User:** ${user.tag} (${user.id})\n` +
        `**Channel:** ${channel}\n` +
        `**Ticket #:** ${ticketNumber}\n` +
        `**Issue:**\n${description.slice(0, 300)}${description.length > 300 ? '...' : ''}`
    });
    await sendToLogChannel(guild, guildConfig.ticket_log_channel_id, logEmbed);

    await interaction.editReply({
      embeds: [buildSuccessEmbed(
        'Ticket Created',
        `Your support ticket has been created: ${channel}\nA staff member will assist you shortly.`
      )]
    });

  } catch (err) {
    logger.error(`Failed to create ticket for ${user.tag}: ${err.message}`);
    await interaction.editReply({
      embeds: [buildErrorEmbed('Creation Failed', 'An error occurred while creating your ticket. Please try again.')]
    });
  }
}

module.exports = { handleTicketCreate, processTicketSubmission };
