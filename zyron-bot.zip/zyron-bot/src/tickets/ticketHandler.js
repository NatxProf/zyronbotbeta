'use strict';

const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../config.json');

async function sendTicketWelcome(channel, user, ticketNumber, description) {
  const embed = new EmbedBuilder()
    .setColor(config.colors.primary)
    .setTitle(`Support Ticket #${ticketNumber}`)
    .setDescription(
      `Welcome, ${user}.\n\n` +
      'A staff member will be with you shortly. ' +
      'Please do not leave this channel while awaiting a response.\n\n' +
      `**Your Issue**\n${description}`
    )
    .addFields(
      { name: 'User',          value: `${user.tag}`,       inline: true  },
      { name: 'Ticket Number', value: `#${ticketNumber}`,  inline: true  },
      { name: 'Status',        value: '🟢 Open',           inline: true  }
    )
    .setFooter({ text: config.embedFooter })
    .setTimestamp();

  const closeButton = new ButtonBuilder()
    .setCustomId('ticket_close')
    .setLabel('Close Ticket')
    .setStyle(ButtonStyle.Danger)
    .setEmoji('🔒');

  const row = new ActionRowBuilder().addComponents(closeButton);

  await channel.send({
    content: `${user}`,
    embeds:  [embed],
    components: [row]
  });
}

async function sendToLogChannel(guild, logChannelId, embed) {
  if (!logChannelId) return;
  const logChannel = guild.channels.cache.get(logChannelId);
  if (!logChannel) return;
  await logChannel.send({ embeds: [embed] }).catch(() => {});
}

module.exports = { sendTicketWelcome, sendToLogChannel };
