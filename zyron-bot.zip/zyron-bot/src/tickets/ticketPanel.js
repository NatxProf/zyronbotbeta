'use strict';

const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../config.json');

function buildTicketPanel() {
  const embed = new EmbedBuilder()
    .setColor(config.colors.primary)
    .setTitle('📋 Support Center')
    .setDescription(
      'Our support team is ready to assist you.\n\n' +
      'Click **Create Ticket** below to open a private support channel. ' +
      'Please describe your issue clearly so staff can assist you efficiently.\n\n' +
      '**Guidelines**\n' +
      '› One active ticket per user at a time\n' +
      '› Provide a clear, detailed description\n' +
      '› Include any relevant context or screenshots'
    )
    .setFooter({ text: config.embedFooter })
    .setTimestamp();

  const button = new ButtonBuilder()
    .setCustomId('ticket_create')
    .setLabel('Create Ticket')
    .setStyle(ButtonStyle.Primary)
    .setEmoji('🎫');

  const row = new ActionRowBuilder().addComponents(button);

  return { embeds: [embed], components: [row] };
}

module.exports = { buildTicketPanel };
