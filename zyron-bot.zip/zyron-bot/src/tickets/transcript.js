'use strict';

const fs     = require('fs');
const path   = require('path');
const logger = require('../core/logger');

async function generateTranscript(channel, ticket) {
  try {
    const fetched = await channel.messages.fetch({ limit: 100 });
    const messages = [...fetched.values()].reverse();

    const separator = '='.repeat(50);
    const lines = [
      `${separator}`,
      `  ZYRON TICKET TRANSCRIPT`,
      `  Ticket #${ticket.ticket_number}`,
      `  Guild: ${channel.guild.name} (${channel.guild.id})`,
      `  User ID: ${ticket.user_id}`,
      `  Opened: ${ticket.created_at}`,
      `  Closed: ${new Date().toISOString()}`,
      `${separator}`,
      ''
    ];

    for (const msg of messages) {
      const ts = msg.createdAt.toISOString();
      if (msg.author.bot && msg.embeds.length) {
        const e = msg.embeds[0];
        lines.push(`[${ts}] [BOT EMBED] ${e.title ?? ''}: ${e.description ?? ''}`);
      } else {
        lines.push(`[${ts}] [${msg.author.tag}]: ${msg.content}`);
      }
    }

    const logsDir  = path.join(__dirname, '../../logs');
    const filename = `ticket-${ticket.ticket_number}-${Date.now()}.txt`;
    const filepath = path.join(logsDir, filename);

    fs.writeFileSync(filepath, lines.join('\n'), 'utf8');
    logger.info(`Transcript saved: ${filename}`);

    return filepath;
  } catch (err) {
    logger.error(`Transcript generation failed: ${err.message}`);
    return null;
  }
}

module.exports = { generateTranscript };
