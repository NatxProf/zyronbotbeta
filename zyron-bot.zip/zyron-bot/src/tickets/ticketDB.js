'use strict';

const {
  createTicketRecord,
  getTicketByChannel,
  getOpenTicketByUser,
  closeTicketRecord
} = require('../database/ticketSchema');
const { incrementTicketCounter } = require('../database/guildSchema');

function generateTicketId() {
  return `tkt_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

async function openTicket({ guildId, channelId, userId, description }) {
  const ticketNumber = incrementTicketCounter(guildId);
  const ticketId     = generateTicketId();

  createTicketRecord({
    ticket_id:     ticketId,
    guild_id:      guildId,
    channel_id:    channelId,
    user_id:       userId,
    ticket_number: ticketNumber,
    description:   description ?? null
  });

  return { ticketId, ticketNumber };
}

module.exports = {
  openTicket,
  getTicketByChannel,
  getOpenTicketByUser,
  closeTicketRecord
};
