'use strict';

const logger = require('./logger');
const { getCooldown, setCooldown } = require('../utils/cooldowns');
const { hasPermission } = require('../utils/permissions');
const { buildErrorEmbed } = require('../utils/embedBuilder');

async function handleCommand(message, client) {
  const prefix = client.prefix;

  if (!message.content.startsWith(prefix) || message.author.bot) return;
  if (!message.guild) return;

  const args        = message.content.slice(prefix.length).trim().split(/\s+/);
  const commandName = args.shift().toLowerCase();
  const subName     = args[0]?.toLowerCase();

  let command = null;
  if (subName) {
    command = client.commands.get(`${commandName} ${subName}`);
    if (command) args.shift();
  }
  if (!command) command = client.commands.get(commandName);
  if (!command) return;

  if (command.permissions) {
    if (!hasPermission(message.member, command.permissions)) {
      return message.reply({
        embeds: [buildErrorEmbed(
          'Permission Denied',
          'You do not have the required permissions to run this command.'
        )]
      });
    }
  }

  const cooldownKey  = `${command.name}-${message.author.id}`;
  const remaining    = getCooldown(cooldownKey);
  if (remaining > 0) {
    return message.reply({
      embeds: [buildErrorEmbed(
        'Cooldown Active',
        `Please wait **${(remaining / 1000).toFixed(1)}s** before using this command again.`
      )]
    });
  }

  if (command.cooldown) setCooldown(cooldownKey, command.cooldown * 1000);

  try {
    await command.execute(message, args, client);
  } catch (err) {
    logger.error(`Command '${commandName}' threw an error: ${err.message}`);
    await message.reply({
      embeds: [buildErrorEmbed(
        'Execution Error',
        'An unexpected error occurred. Please try again or contact a staff member.'
      )]
    }).catch(() => {});
  }
}

module.exports = { handleCommand };
