'use strict';

const {
  Client,
  GatewayIntentBits,
  Partials,
  Collection
} = require('discord.js');
const { Loader } = require('./loader');
const logger = require('./logger');

class ZyronClient extends Client {
  constructor() {
    super({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.MessageContent
      ],
      partials: [Partials.Channel, Partials.Message]
    });

    /** @type {Collection<string, object>} */
    this.commands = new Collection();

    /** @type {Collection<string, number>} */
    this.cooldowns = new Collection();

    this.prefix = process.env.DEFAULT_PREFIX || 'zt!';
  }

  async start() {
    const loader = new Loader(this);
    await loader.loadCommands();
    await loader.loadEvents();

    logger.info('Connecting to Discord...');
    await this.login(process.env.BOT_TOKEN);
  }
}

module.exports = { ZyronClient };
