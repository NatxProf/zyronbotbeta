'use strict';

const fs   = require('fs');
const path = require('path');
const logger = require('./logger');

class Loader {
  constructor(client) {
    this.client = client;
  }

  async loadCommands() {
    const commandsPath = path.join(__dirname, '../commands');
    const categories   = fs.readdirSync(commandsPath);
    let count = 0;

    for (const category of categories) {
      const categoryPath = path.join(commandsPath, category);
      if (!fs.statSync(categoryPath).isDirectory()) continue;

      const files = fs.readdirSync(categoryPath).filter(f => f.endsWith('.js'));

      for (const file of files) {
        const filePath = path.join(categoryPath, file);
        const command  = require(filePath);

        if (!command.name || !command.execute) {
          logger.warn(`Skipping ${filePath}: missing 'name' or 'execute'.`);
          continue;
        }

        command.category = category;

        const key = command.subcommand
          ? `${command.name} ${command.subcommand}`
          : command.name;

        this.client.commands.set(key, command);
        count++;
      }
    }

    logger.info(`Loaded ${count} command(s) across ${categories.length} category folder(s).`);
  }

  async loadEvents() {
    const eventsPath = path.join(__dirname, '../events');
    const files = fs.readdirSync(eventsPath).filter(f => f.endsWith('.js'));
    let count = 0;

    for (const file of files) {
      const filePath = path.join(eventsPath, file);
      const event    = require(filePath);

      if (!event.name || !event.execute) {
        logger.warn(`Skipping ${filePath}: missing 'name' or 'execute'.`);
        continue;
      }

      const handler = (...args) => event.execute(...args, this.client);

      event.once
        ? this.client.once(event.name, handler)
        : this.client.on(event.name, handler);

      count++;
    }

    logger.info(`Registered ${count} event listener(s).`);
  }
}

module.exports = { Loader };
