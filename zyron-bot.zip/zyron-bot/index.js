'use strict';

require('dotenv').config();
const { ZyronClient } = require('./src/core/client');

const client = new ZyronClient();

client.start().catch((err) => {
  console.error('[FATAL] Failed to start Zyron:', err);
  process.exit(1);
});

process.on('unhandledRejection', (reason) => {
  console.error('[UnhandledRejection]', reason);
});

process.on('uncaughtException', (err) => {
  console.error('[UncaughtException]', err);
  process.exit(1);
});
