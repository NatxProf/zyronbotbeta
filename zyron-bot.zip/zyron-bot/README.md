# Zyron — Professional Discord Server Assistant

Zyron is a modular Discord bot providing structured support ticketing,
server management utilities, and administrative tools.

## Setup

1. Clone the repository and install dependencies:
   ```
   npm install
   ```

2. Copy `.env.example` to `.env` and fill in your bot token:
   ```
   cp .env.example .env
   ```

3. Start the bot:
   ```
   npm start
   ```

## Command Reference

### Ticket Management (`zt!ticket`)
| Command                      | Description                                 |
|------------------------------|---------------------------------------------|
| `zt!ticket setup`            | Initialize the ticket system                |
| `zt!ticket enable`           | Activate ticket functionality               |
| `zt!ticket disable`          | Deactivate ticket functionality             |
| `zt!ticket panel`            | Send the ticket creation panel              |
| `zt!ticket close`            | Close the current ticket channel            |
| `zt!ticket logs <#channel>`  | Set the ticket log channel                  |
| `zt!ticket category <id>`    | Set the ticket category (use category ID)   |

### Administration
| Command                      | Description                                 |
|------------------------------|---------------------------------------------|
| `zt!say <message>`           | Send a plain-text message as the bot        |
| `zt!announce <message>`      | Send a formatted announcement embed         |
| `zt!embed <title\|desc>`     | Send a structured embed                     |
| `zt!purge <amount>`          | Bulk delete messages (max 100)              |

### Utility
| Command       | Description                                      |
|---------------|--------------------------------------------------|
| `zt!help`     | Display all commands and categories              |
| `zt!ping`     | Check bot latency                                |
| `zt!stats`    | Display bot statistics                           |

### Configuration
| Command                      | Description                                 |
|------------------------------|---------------------------------------------|
| `zt!prefix <new_prefix>`     | Change the guild command prefix             |
| `zt!status set <type> <text>`| Manually set bot status                     |
| `zt!status reset`            | Resume automatic status rotation            |

## Requirements
- Node.js >= 18.0.0
- Discord.js v14
- Bot requires the Message Content intent enabled in the Developer Portal
